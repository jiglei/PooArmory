from urllib.parse import urlencode
from urllib.request import Request, urlopen
#POST ?input=...
url = 'https://javascript-minifier.com/raw' # Set destination URL here
input = open("poo.js").read()
post_fields = {'input': input}     # Set POST fields here

request = Request(url, urlencode(post_fields).encode())
json = urlopen(request).read().decode()
print(json)